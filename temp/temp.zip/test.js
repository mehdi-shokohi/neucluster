if(typeof process.family === 'undefined') console.log('ok')
process.prototype={name :"salam"}
console.log(process.pid)
console.log(process.prototype.name)

