// import our modules
var EventEmitter = require('events')
const cluster = require('cluster');



class MMicrosSchedule extends EventEmitter{

  constructor(Job_path,files){
    super()

    this.jPath=Job_path
    this.files=files

  }


  onMessagehandler(mess){
    // return new  Promise((resolve, reject) => {

        // console.log(`Worker ${process.pid} recevies message '${JSON.stringify(message)}'`);
        // this.type = 'sch'
    // console.log(this.files)
    // let index=(cluster.worker.id)-;
    //   // if(index<this.files.length && index>=0){
    //     let addressWorker = this.jPath + "/" + this.files[index];
    //     require(addressWorker).JobRunning();
    if(mess.type==='sch')
        console.log(`Schedule >>>>>> Worker ${process.pid} For  Schedule System `);
        // resolve()
      // }
      // reject()
    // })
  }
  run(){
    if (cluster.isMaster) {
      for (let i = 0; i < this.files.length; i++) {

       const worker =  cluster.fork();
       worker.send({type : 'sch'})
      }
    }
    process.on('message',this.onMessagehandler);

    // else if(cluster.isWorker ){
    //   let index=(cluster.worker.id)-1;
    //   if(index<this.files.length && index>=0){
    //   let addressWorker = this.jPath + "/" + this.files[index];
    //   require(addressWorker).JobRunning();
    //   console.log(`Schedule Worker ${process.pid} For  Schedule System `);
    // }
    // }

  }




  runExec(){
  const { exec } = require('child_process');

  const child = exec('node', [__dirname+'/../runner.js'], ()=>{

  });
}




}

module.exports=MMicrosSchedule