class Serv_one{

  constructor (){

  }

  job_run(){
    console.log(__filename)
  }
}


module.exports=Serv_one;